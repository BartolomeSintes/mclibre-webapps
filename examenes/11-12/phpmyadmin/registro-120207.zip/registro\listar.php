<?php
/**
 * Registro simple -  listar.php
 * 
 * @author    Bartolom� Sintes Marco <bartolome.sintes+mclibre@gmail.com>
 * @copyright 2012 Bartolom� Sintes Marco
 * @license   http://www.gnu.org/licenses/agpl.txt AGPL 3 or later
 * @version   2012-02-07
 * @link      http://www.mclibre.org
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

include('funciones.php');
session_start();

if (!isset($_SESSION['multiagendaUsuario'])) {
    header('Location:index.php');
    exit();
} else {
    $db = conectaDb();
    cabecera('Listar', CABECERA_SIN_CURSOR, $_SESSION['multiagendaUsuario']);

    $campo = recogeParaConsulta($db, 'campo', 'usuario'); 
    $campo = quitaComillasExteriores($campo); 
    $orden = recogeParaConsulta($db, 'orden', 'ASC'); 
    $orden = quitaComillasExteriores($orden);
    
    $consulta = "SELECT COUNT(*) FROM $dbUsuarios  
        WHERE id='$_SESSION[multiagendaIdUsuario]'";
    $result = $db->query($consulta);
    if (!$result) {
        print "<p>Error en la consulta.</p>\n";
    } elseif ($result->fetchColumn()==0) {
        print "<p>No se ha creado todav�a ning�n registro.</p>\n";
    } else {
        $consulta = "SELECT * FROM $dbUsuarios 
            ORDER BY $campo $orden";
        $result = $db->query($consulta);
        if (!$result) {
            print "<p>Error en la consulta.</p>\n";
        } else {
            print "<p>Listado completo de registros:</p>\n<table border=\"1\">
      <thead>
        <tr class=\"neg\">
          <th><a href=\"$_SERVER[PHP_SELF]?campo=usuario&amp;orden=ASC\">
            <img src=\"abajo.png\" alt=\"A-Z\" title=\"A-Z\" /></a>
            Usuario
            <a href=\"$_SERVER[PHP_SELF]?campo=usuario&amp;orden=DESC\">
            <img src=\"arriba.png\" alt=\"Z-A\" title=\"Z-A\" /></a></th>
          <th><a href=\"$_SERVER[PHP_SELF]?campo=password&amp;orden=ASC\">
            <img src=\"abajo.png\" alt=\"A-Z\" title=\"A-Z\" /></a>
            Password 
            <a href=\"$_SERVER[PHP_SELF]?campo=password&amp;orden=DESC\">
            <img src=\"arriba.png\" alt=\"Z-A\" title=\"Z-A\" /></a></th>
        </tr>
      </thead>
      <tbody>\n";
            $tmp = TRUE;
            foreach ($result as $valor) {
                if ($tmp) {
                    print "    <tr>\n";
                } else {
                    print "    <tr class=\"neg\">\n";
                }
                $tmp = !$tmp;
                print "      <td>$valor[usuario]</td>
          <td>$valor[password]</td>\n    </tr>\n";
            }
            print "  </tbody>\n</table>\n";
        }
    }
    
    $db = NULL;
    pie();
}
?>
