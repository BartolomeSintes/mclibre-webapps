<?php
/**
 * Bases de datos 2-3 - modificar2.php
 *
 * @author    Bartolom� Sintes Marco <bartolome.sintes+mclibre@gmail.com>
 * @copyright 2012 Bartolom� Sintes Marco
 * @license   http://www.gnu.org/licenses/agpl.txt AGPL 3 or later
 * @version   2012-11-27
 * @link      http://www.mclibre.org
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

require_once "biblioteca.php";

$db = conectaDb();

$id = recoge("id");

if ($id == "") {
    cabecera("Modificar 2", MENU_VOLVER, CABECERA_SIN_CURSOR);
    print "<p>No se ha seleccionado ning�n registro.</p>\n";
} else {
    $consulta = "SELECT COUNT(*) FROM $dbTabla
       WHERE id=:id";
    $result = $db->prepare($consulta);
    $result->execute(array(":id" => $id));
    if (!$result) {
        cabecera("Modificar 2", MENU_VOLVER, CABECERA_SIN_CURSOR);
        print "<p>Error en la consulta.</p>\n";
    } elseif ($result->fetchColumn() == 0) {
        cabecera("Modificar 2", MENU_VOLVER, CABECERA_SIN_CURSOR);
        print "<p>Registro no encontrado.</p>\n";
    } else {
        $consulta = "SELECT * FROM $dbTabla
            WHERE id=:id";
        $result = $db->prepare($consulta);
        $result->execute(array(":id" => $id));
        if (!$result) {
            cabecera("Modificar 2", MENU_VOLVER, CABECERA_SIN_CURSOR);
            print "<p>Error en la consulta.</p>\n";
        } else {
            cabecera("Modificar 2", MENU_VOLVER, CABECERA_CON_CURSOR);
            $valor = $result->fetch();
            print "<form action=\"modificar3.php\" method=\"" . FORM_METHOD . "\">
  <p>Modifique los campos que desee:</p>
  <table>
    <tbody>
      <tr>
        <td>Nombre:</td>
        <td><input type=\"text\" name=\"nombre\" size=\"$tamNombre\" "
                . "maxlength=\"$tamNombre\" value=\"$valor[nombre]\" id=\"cursor\" /></td>
      </tr>
      <tr>
        <td>Apellidos:</td>
        <td><input type=\"text\" name=\"apellidos\" size=\"$tamApellidos\" "
                . "maxlength=\"$tamApellidos\" value=\"$valor[apellidos]\" /></td>
      </tr>
      <tr>
        <td>Tel�fono:</td>
        <td><input type=\"text\" name=\"telefono\" size=\"$tamTelefono\" "
                . "maxlength=\"$tamTelefono\" value=\"$valor[telefono]\" /></td>
      </tr>
      <tr>
        <td>Correo:</td>
        <td><input type=\"text\" name=\"correo\" size=\"$tamCorreo\" "
                . "maxlength=\"$tamCorreo\" value=\"$valor[correo]\" /></td>
      </tr>
    </tbody>
  </table>
  <p><input type=\"hidden\" name=\"id\" value=\"$id\" />
    <input type=\"submit\" value=\"Actualizar\" /></p>
</form>\n";
        }
    }
}

$db = NULL;
pie();
?>
